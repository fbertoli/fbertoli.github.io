The name of an instance is X-nN-hH—F-i.txt where
X  = represents the type of map: (C for cluster map, R for random map)
N  = is the number of original customers, i.e. the customer that place orders on several days
H  = is the number of days in the horizon
F  = is the frequency with which the customers place order (f for frequent, r for rare)
i  = is the number of the instance (5 for each tuple (map, n, h, frequency)

————————————————————————————————————————————————————————————————————————————————————————————————
————————————————————————————————————————————————————————————————————————————————————————————————

The first line of instance has 4 entries:

n h total_requests d

where n is N above, h is H above and d in the number of total requests in the instance
The next line represents the depot (located in the origin).
Then there is a line for each request in the following format:
	
customer_id 	x_coord		y_coord		demand		day

The customer_id varies between 1 and n. The days are indexed from 0 to h-1.


————————————————————————————————————————————————————————————————————————————————————————————————
————————————————————————————————————————————————————————————————————————————————————————————————

An example follows:


2 3 total_requests 4 	
0 	0 	0
1	44	9	27	0
1	44	9	33	1
2	42	-2	6	0
2	42	-2	9	1

2 customers placing orders on 3 days for a total of 4 requests
customer 1 is located at (44,9) and order 27 od day 0 and 33 on day 1.
customer 2 is located at (42,-2) and order 6 od day 0 and 9 on day 1.