days: number of days in the instance
territories: number of drivers/territories
capacity: capacity of the vehicle
customers: number of total customers in the instance

Next lines give information about the customers. For a given customer, the service time and time windows are the same every day.


Section “requests”: each line is structured as follows:
customer list of days where the customer place a request

Section “demands”: each line is structured as follows:
customer list of demands for the days listed in the “request” section


Section “distances”: each line is structured as follows:
customer1 - customer2 - distance between customer 1 and 2 -  traveling time between customer 1 and 2


Note!! The distance and time matrixes might be not symmetrical.